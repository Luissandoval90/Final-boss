package com.luissandoval.finalboss.manager;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.ability.PowerExecutor;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Maneja el ciclo de vida del modo Final Boss: activacion, desactivacion,
 * escala gigante, regeneracion pasiva, resistencia a dano y la BossBar visual.
 * El boss SIEMPRE puede recibir daño de jugadores normalmente (no hay invulnerabilidad).
 */
public class BossManager {

    private final FinalBossPlugin plugin;
    private final DiscordNotifier discordNotifier;
    private final PowerExecutor powerExecutor;
    private final SpawnEffectManager spawnEffectManager;

    private boolean active = false;
    private UUID bossUuid;
    private BossBar bossBar;
    private BukkitTask regenTask;

    // Cooldowns por poder, guardados aqui para que tanto el GUI como los items fisicos los compartan
    private final Map<String, Long> lastUsedByConfigKey = new HashMap<>();

    private static final String RESISTANCE_MODIFIER_NAME = "finalboss-damage-resistance";
    private static final String SPEED_MODIFIER_NAME = "finalboss-speed-boost";
    private static final String ATTACK_MODIFIER_NAME = "finalboss-attack-bonus";
    private static final String SCALE_MODIFIER_NAME = "finalboss-giant-scale";
    private static final String TEMP_SCALE_MODIFIER_NAME = "finalboss-temp-scale-boost";

    public BossManager(FinalBossPlugin plugin, DiscordNotifier discordNotifier) {
        this.plugin = plugin;
        this.discordNotifier = discordNotifier;
        this.powerExecutor = new PowerExecutor(plugin, this);
        this.spawnEffectManager = new SpawnEffectManager(plugin);
    }

    public boolean isActive() {
        return active;
    }

    public UUID getBossUuid() {
        return bossUuid;
    }

    public Player getBossPlayer() {
        return bossUuid != null ? Bukkit.getPlayer(bossUuid) : null;
    }

    public PowerExecutor getPowerExecutor() {
        return powerExecutor;
    }

    public boolean isBoss(Player player) {
        return active && bossUuid != null && bossUuid.equals(player.getUniqueId());
    }

    public boolean activate(Player boss) {
        if (active) {
            return false;
        }

        active = true;
        bossUuid = boss.getUniqueId();

        spawnEffectManager.playSpawnSequence(boss);
        applyBossStats(boss);
        setupBossBar(boss);
        startRegenTask();
        plugin.getPowerItemManager().givePowerItem(boss);

        String rawMsg = plugin.getConfig().getString("messages.boss-activated", "&c%player% es el Final Boss")
                .replace("%player%", boss.getName());
        broadcast(rawMsg);

        if (plugin.getConfig().getBoolean("discord.notify-on-activation", true)) {
            discordNotifier.sendMessage("**" + boss.getName() + "** se ha convertido en el FINAL BOSS. Que comience el caos.");
        }

        return true;
    }

    public boolean deactivate(boolean bossDefeated) {
        return deactivate(bossDefeated, null);
    }

    /**
     * Desactiva el modo Final Boss. Si "killer" no es null, se anuncia quien lo derroto
     * usando el mensaje "boss-defeated-by"; si es null, se usa el mensaje generico "boss-defeated".
     */
    public boolean deactivate(boolean bossDefeated, Player killer) {
        if (!active) {
            return false;
        }

        Player boss = getBossPlayer();
        if (boss != null) {
            removeBossStats(boss);
        }

        if (bossBar != null) {
            Bukkit.getOnlinePlayers().forEach(p -> p.hideBossBar(bossBar));
            bossBar = null;
        }

        if (regenTask != null) {
            regenTask.cancel();
            regenTask = null;
        }

        active = false;
        bossUuid = null;
        lastUsedByConfigKey.clear();

        if (bossDefeated) {
            String rawMsg;
            if (killer != null) {
                rawMsg = plugin.getConfig().getString("messages.boss-defeated-by",
                                "&a¡%killer% ha derrotado al Final Boss!")
                        .replace("%killer%", killer.getName());
            } else {
                rawMsg = plugin.getConfig().getString("messages.boss-defeated", "&aEl Final Boss ha caido");
            }
            broadcast(rawMsg);

            if (plugin.getConfig().getBoolean("discord.notify-on-defeat", true)) {
                String killerPart = killer != null ? " a manos de **" + killer.getName() + "**" : "";
                discordNotifier.sendMessage("El **Final Boss** ha sido derrotado" + killerPart + ". Los sobrevivientes ganan la partida.");
            }
        }

        return true;
    }

    private void applyBossStats(Player boss) {
        double maxHealth = plugin.getConfig().getDouble("boss-stats.max-health", 500.0);
        double resistancePercent = plugin.getConfig().getDouble("boss-stats.damage-resistance-percent", 25.0);
        double speedMultiplier = plugin.getConfig().getDouble("boss-stats.movement-speed-multiplier", 1.15);
        double attackBonus = plugin.getConfig().getDouble("boss-stats.attack-damage-bonus", 8.0);
        double scale = plugin.getConfig().getDouble("boss-stats.scale", 2.5);

        AttributeInstance healthAttr = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (healthAttr != null) {
            healthAttr.setBaseValue(maxHealth);
        }
        boss.setHealth(maxHealth);

        addOrReplaceModifier(boss, Attribute.GENERIC_ARMOR_TOUGHNESS, RESISTANCE_MODIFIER_NAME,
                (resistancePercent / 100.0) * 20.0, AttributeModifier.Operation.ADD_NUMBER);

        AttributeInstance speedAttr = boss.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) {
            double baseSpeed = speedAttr.getBaseValue();
            addOrReplaceModifier(boss, Attribute.GENERIC_MOVEMENT_SPEED, SPEED_MODIFIER_NAME,
                    baseSpeed * (speedMultiplier - 1.0), AttributeModifier.Operation.ADD_NUMBER);
        }

        addOrReplaceModifier(boss, Attribute.GENERIC_ATTACK_DAMAGE, ATTACK_MODIFIER_NAME,
                attackBonus, AttributeModifier.Operation.ADD_NUMBER);

        // Escala real gigante (Paper/Bukkit 1.20.5+): afecta hitbox, colision y modelo visual
        AttributeInstance scaleAttr = boss.getAttribute(Attribute.GENERIC_SCALE);
        if (scaleAttr != null) {
            addOrReplaceModifier(boss, Attribute.GENERIC_SCALE, SCALE_MODIFIER_NAME,
                    scale - 1.0, AttributeModifier.Operation.ADD_NUMBER);
        }
    }

    private void removeBossStats(Player boss) {
        removeModifierSafely(boss, Attribute.GENERIC_ARMOR_TOUGHNESS, RESISTANCE_MODIFIER_NAME);
        removeModifierSafely(boss, Attribute.GENERIC_MOVEMENT_SPEED, SPEED_MODIFIER_NAME);
        removeModifierSafely(boss, Attribute.GENERIC_ATTACK_DAMAGE, ATTACK_MODIFIER_NAME);
        removeModifierSafely(boss, Attribute.GENERIC_SCALE, SCALE_MODIFIER_NAME);
        removeModifierSafely(boss, Attribute.GENERIC_SCALE, TEMP_SCALE_MODIFIER_NAME);

        AttributeInstance healthAttr = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (healthAttr != null) {
            healthAttr.setBaseValue(20.0);
        }
        if (boss.getHealth() > 20.0) {
            boss.setHealth(20.0);
        }
    }

    private void addOrReplaceModifier(Player player, Attribute attribute, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance attr = player.getAttribute(attribute);
        if (attr == null) return;
        removeModifierSafely(player, attribute, name);
        attr.addModifier(new AttributeModifier(name, amount, op));
    }

    private void removeModifierSafely(Player player, Attribute attribute, String modifierName) {
        AttributeInstance attr = player.getAttribute(attribute);
        if (attr == null) return;
        attr.getModifiers().stream()
                .filter(mod -> mod.getName().equals(modifierName))
                .findFirst()
                .ifPresent(attr::removeModifier);
    }

    /**
     * Aplica un incremento TEMPORAL de escala (usado por la habilidad "Furia Titan"),
     * separado del modificador de escala base para que no se pisen.
     */
    public void applyTemporaryScaleBoost(Player boss, double extraScale, int durationTicks) {
        AttributeInstance scaleAttr = boss.getAttribute(Attribute.GENERIC_SCALE);
        if (scaleAttr == null) return;

        addOrReplaceModifier(boss, Attribute.GENERIC_SCALE, TEMP_SCALE_MODIFIER_NAME, extraScale, AttributeModifier.Operation.ADD_NUMBER);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (isActive() && boss.isOnline()) {
                removeModifierSafely(boss, Attribute.GENERIC_SCALE, TEMP_SCALE_MODIFIER_NAME);
            }
        }, durationTicks);
    }

    private void setupBossBar(Player boss) {
        String rawTitle = plugin.getConfig().getString("bossbar.title", "&4Final Boss: %player%")
                .replace("%player%", boss.getName());
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(rawTitle);

        String colorName = plugin.getConfig().getString("bossbar.color", "RED");
        String styleName = plugin.getConfig().getString("bossbar.style", "SEGMENTED_10");

        BossBar.Color color;
        BossBar.Overlay overlay;
        try {
            color = BossBar.Color.valueOf(colorName);
        } catch (IllegalArgumentException e) {
            color = BossBar.Color.RED;
        }
        try {
            overlay = BossBar.Overlay.valueOf(styleName);
        } catch (IllegalArgumentException e) {
            overlay = BossBar.Overlay.NOTCHED_10;
        }

        bossBar = BossBar.bossBar(title, 1.0f, color, overlay);

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showBossBar(bossBar);
        }
    }

    public void updateBossBar() {
        Player boss = getBossPlayer();
        if (boss == null || bossBar == null) return;

        AttributeInstance healthAttr = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        double maxHealth = healthAttr != null ? healthAttr.getBaseValue() : 20.0;
        float progress = (float) Math.max(0.0, Math.min(1.0, boss.getHealth() / maxHealth));
        bossBar.progress(progress);
    }

    private void startRegenTask() {
        double regenPerSecond = plugin.getConfig().getDouble("boss-stats.natural-regen-per-second", 1.5);

        regenTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Player boss = getBossPlayer();
            if (boss == null || !active) return;

            AttributeInstance healthAttr = boss.getAttribute(Attribute.GENERIC_MAX_HEALTH);
            double maxHealth = healthAttr != null ? healthAttr.getBaseValue() : 20.0;

            double newHealth = Math.min(maxHealth, boss.getHealth() + regenPerSecond);
            boss.setHealth(newHealth);

            updateBossBar();
        }, 20L, 20L);
    }

    // --- Gestion de cooldowns compartida entre GUI e items fisicos ---

    public long getRemainingCooldownSeconds(String configKey, int cooldownSeconds) {
        long now = System.currentTimeMillis();
        long last = lastUsedByConfigKey.getOrDefault(configKey, 0L);
        long remainingMs = (last + (cooldownSeconds * 1000L)) - now;
        return remainingMs > 0 ? (remainingMs / 1000) + 1 : 0;
    }

    public void markUsed(String configKey) {
        lastUsedByConfigKey.put(configKey, System.currentTimeMillis());
    }

    public void broadcast(String rawMessage) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        Component message = LegacyComponentSerializer.legacyAmpersand().deserialize(prefix + rawMessage);
        Bukkit.broadcast(message);
    }

    public void shutdown() {
        if (regenTask != null) {
            regenTask.cancel();
        }
        if (bossBar != null) {
            Bukkit.getOnlinePlayers().forEach(p -> p.hideBossBar(bossBar));
        }
        lastUsedByConfigKey.clear();
    }
}
