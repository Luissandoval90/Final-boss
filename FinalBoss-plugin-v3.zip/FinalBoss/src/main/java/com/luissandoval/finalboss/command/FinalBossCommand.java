package com.luissandoval.finalboss.command;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.gui.PowerMenuGui;
import com.luissandoval.finalboss.gui.StartSelectionGui;
import com.luissandoval.finalboss.manager.BossManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class FinalBossCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of(
            "start", "activate", "deactivate", "menu", "setboss", "status", "reload", "giveitems"
    );

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;
    private final com.luissandoval.finalboss.gui.StartSelectionListener startSelectionListener;

    public FinalBossCommand(FinalBossPlugin plugin, BossManager bossManager,
                             com.luissandoval.finalboss.gui.StartSelectionListener startSelectionListener) {
        this.plugin = plugin;
        this.bossManager = bossManager;
        this.startSelectionListener = startSelectionListener;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("finalboss.admin")) {
            sendMessage(sender, plugin.getConfig().getString("messages.no-permission", "&cSin permiso."));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "start" -> handleStart(sender);
            case "activate" -> handleActivate(sender, args);
            case "deactivate" -> handleDeactivate(sender);
            case "menu" -> handleMenu(sender);
            case "setboss" -> handleSetBoss(sender, args);
            case "status" -> handleStatus(sender);
            case "reload" -> handleReload(sender);
            case "giveitems" -> handleGiveItems(sender);
            default -> sendUsage(sender);
        }

        return true;
    }

    private void handleStart(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sendMessage(sender, "&cSolo un jugador puede usar /finalboss start.");
            return;
        }

        if (bossManager.isActive()) {
            sendMessage(sender, plugin.getConfig().getString("messages.boss-already-active", "&cYa esta activo."));
            return;
        }

        if (plugin.getCountdownManager().isCountdownInProgress()) {
            sendMessage(sender, "&cYa hay una cuenta regresiva en curso.");
            return;
        }

        Map<Integer, UUID> slotMap = new HashMap<>();
        Inventory gui = StartSelectionGui.build(player, slotMap);
        startSelectionListener.registerOpenGui(player, slotMap);
        player.openInventory(gui);
    }

    private void handleActivate(CommandSender sender, String[] args) {
        if (bossManager.isActive()) {
            sendMessage(sender, plugin.getConfig().getString("messages.boss-already-active", "&cYa esta activo."));
            return;
        }

        Player target;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sendMessage(sender, "&cJugador no encontrado o no esta en linea: " + args[1]);
                return;
            }
        } else {
            String configuredBoss = plugin.getConfig().getString("boss-player", "");
            target = Bukkit.getPlayerExact(configuredBoss);
            if (target == null) {
                sendMessage(sender, "&cEl jugador configurado como boss (" + configuredBoss + ") no esta en linea. Usa /finalboss activate <jugador>");
                return;
            }
        }

        boolean activated = bossManager.activate(target);
        if (activated) {
            sendMessage(sender, "&aFinal Boss activado para: " + target.getName());
        }
    }

    private void handleDeactivate(CommandSender sender) {
        if (!bossManager.isActive()) {
            sendMessage(sender, plugin.getConfig().getString("messages.boss-not-active", "&cNo esta activo."));
            return;
        }
        bossManager.deactivate(false);
        sendMessage(sender, "&aModo Final Boss desactivado manualmente (sin anuncio de victoria).");
    }

    private void handleMenu(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sendMessage(sender, "&cSolo un jugador puede abrir el menu.");
            return;
        }

        if (!bossManager.isActive() || !bossManager.isBoss(player)) {
            sendMessage(sender, "&cSolo el Final Boss activo puede abrir este menu.");
            return;
        }

        player.openInventory(PowerMenuGui.build(plugin, bossManager));
    }

    private void handleSetBoss(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sendMessage(sender, "&cUso: /finalboss setboss <jugador>");
            return;
        }

        plugin.getConfig().set("boss-player", args[1]);
        plugin.saveConfig();
        sendMessage(sender, "&aJugador configurado como Final Boss: " + args[1]);
    }

    private void handleStatus(CommandSender sender) {
        if (!bossManager.isActive()) {
            sendMessage(sender, "&7Estado: &cinactivo");
            return;
        }

        Player boss = bossManager.getBossPlayer();
        String bossName = boss != null ? boss.getName() : "desconocido (offline)";
        String health = boss != null ? String.format("%.1f", boss.getHealth()) : "N/A";

        sendMessage(sender, "&7Estado: &aactivo &7| Boss: &e" + bossName + " &7| Vida: &c" + health);
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        sendMessage(sender, "&aConfiguracion recargada correctamente.");
    }

    private void handleGiveItems(CommandSender sender) {
        Player boss = bossManager.getBossPlayer();
        if (!bossManager.isActive() || boss == null) {
            sendMessage(sender, "&cEl Final Boss no esta activo o no esta en linea.");
            return;
        }
        plugin.getPowerItemManager().givePowerItem(boss);
        sendMessage(sender, "&aItem de poderes reentregado a " + boss.getName() + ".");
    }

    private void sendUsage(CommandSender sender) {
        sendMessage(sender, "&7Uso: &f/finalboss <activate|deactivate|menu|setboss|status|reload|giveitems>");
    }

    private void sendMessage(CommandSender sender, String rawMessage) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        Component message = LegacyComponentSerializer.legacyAmpersand().deserialize(prefix + rawMessage);
        sender.sendMessage(message);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.addAll(SUBCOMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList()));
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("activate") || args[0].equalsIgnoreCase("setboss")) {
                completions.addAll(Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(name -> name.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList()));
            }
        }

        return completions;
    }
}
