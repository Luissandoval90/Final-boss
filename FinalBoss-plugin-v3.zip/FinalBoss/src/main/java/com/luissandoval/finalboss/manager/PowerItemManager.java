package com.luissandoval.finalboss.manager;

import com.luissandoval.finalboss.FinalBossPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Gestiona el item fisico ("Menu de Poderes") que el Final Boss recibe en su hotbar
 * al activarse. Al usarlo (clic derecho) se abre el mismo GUI que /finalboss menu.
 */
public class PowerItemManager {

    private final FinalBossPlugin plugin;
    private final NamespacedKey powerItemKey;

    public PowerItemManager(FinalBossPlugin plugin) {
        this.plugin = plugin;
        this.powerItemKey = new NamespacedKey(plugin, "finalboss_power_item");
    }

    public NamespacedKey getPowerItemKey() {
        return powerItemKey;
    }

    public ItemStack createPowerItem() {
        String materialName = plugin.getConfig().getString("power-item.material", "NETHER_STAR");
        Material material;
        try {
            material = Material.valueOf(materialName);
        } catch (IllegalArgumentException e) {
            material = Material.NETHER_STAR;
        }

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        String rawName = plugin.getConfig().getString("power-item.name", "&d&l✦ Menu de Poderes ✦");
        Component name = LegacyComponentSerializer.legacyAmpersand().deserialize(rawName)
                .decoration(TextDecoration.ITALIC, false);
        meta.displayName(name);

        meta.getPersistentDataContainer().set(powerItemKey, PersistentDataType.BOOLEAN, true);
        item.setItemMeta(meta);

        return item;
    }

    public boolean isPowerItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(powerItemKey, PersistentDataType.BOOLEAN);
    }

    public void givePowerItem(Player player) {
        int slot = plugin.getConfig().getInt("power-item.slot", 8);
        ItemStack item = createPowerItem();
        player.getInventory().setItem(slot, item);
    }
}
