package com.luissandoval.finalboss;

import com.luissandoval.finalboss.command.FinalBossCommand;
import com.luissandoval.finalboss.gui.PowerMenuListener;
import com.luissandoval.finalboss.gui.StartSelectionListener;
import com.luissandoval.finalboss.listener.CombatListener;
import com.luissandoval.finalboss.listener.PlayerDeathListener;
import com.luissandoval.finalboss.listener.PowerItemListener;
import com.luissandoval.finalboss.manager.BossManager;
import com.luissandoval.finalboss.manager.CountdownManager;
import com.luissandoval.finalboss.manager.DiscordNotifier;
import com.luissandoval.finalboss.manager.PowerItemManager;
import org.bukkit.plugin.java.JavaPlugin;

public class FinalBossPlugin extends JavaPlugin {

    private static FinalBossPlugin instance;
    private BossManager bossManager;
    private DiscordNotifier discordNotifier;
    private PowerItemManager powerItemManager;
    private CountdownManager countdownManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        this.discordNotifier = new DiscordNotifier(this);
        this.bossManager = new BossManager(this, discordNotifier);
        this.powerItemManager = new PowerItemManager(this);
        this.countdownManager = new CountdownManager(this, bossManager);

        StartSelectionListener startSelectionListener = new StartSelectionListener(this, countdownManager);

        getServer().getPluginManager().registerEvents(new PlayerDeathListener(this, bossManager), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this, bossManager), this);
        getServer().getPluginManager().registerEvents(new PowerItemListener(this, bossManager), this);
        getServer().getPluginManager().registerEvents(new PowerMenuListener(this, bossManager), this);
        getServer().getPluginManager().registerEvents(startSelectionListener, this);

        FinalBossCommand commandExecutor = new FinalBossCommand(this, bossManager, startSelectionListener);
        getCommand("finalboss").setExecutor(commandExecutor);
        getCommand("finalboss").setTabCompleter(commandExecutor);
        if (getCommand("fb") != null) {
            getCommand("fb").setExecutor(commandExecutor);
            getCommand("fb").setTabCompleter(commandExecutor);
        }

        getLogger().info("FinalBoss v2 plugin activado correctamente.");
    }

    @Override
    public void onDisable() {
        if (bossManager != null) {
            bossManager.shutdown();
        }
        getLogger().info("FinalBoss plugin desactivado.");
    }

    public static FinalBossPlugin getInstance() {
        return instance;
    }

    public BossManager getBossManager() {
        return bossManager;
    }

    public DiscordNotifier getDiscordNotifier() {
        return discordNotifier;
    }

    public PowerItemManager getPowerItemManager() {
        return powerItemManager;
    }

    public CountdownManager getCountdownManager() {
        return countdownManager;
    }
}
