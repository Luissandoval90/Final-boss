package com.luissandoval.finalboss.ability;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.manager.BossManager;
import com.luissandoval.finalboss.model.PowerType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

/**
 * Ejecuta la logica real de cada poder. Es invocado tanto desde el GUI de poderes
 * como desde los items fisicos, para que el cooldown y comportamiento sean identicos.
 */
public class PowerExecutor {

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;

    public PowerExecutor(FinalBossPlugin plugin, BossManager bossManager) {
        this.plugin = plugin;
        this.bossManager = bossManager;
    }

    public static class ExecutionResult {
        private final boolean success;
        private final String failureMessage;

        private ExecutionResult(boolean success, String failureMessage) {
            this.success = success;
            this.failureMessage = failureMessage;
        }

        public static ExecutionResult ok() {
            return new ExecutionResult(true, null);
        }

        public static ExecutionResult fail(String msg) {
            return new ExecutionResult(false, msg);
        }

        public boolean isSuccess() {
            return success;
        }

        public String getFailureMessage() {
            return failureMessage;
        }
    }

    /**
     * Ejecuta un poder. Si el poder requiere objetivo (SELF_OR_OTHER), "target" debe venir dado
     * (ya resuelto desde el GUI de seleccion). Para poderes NONE, "target" se ignora.
     */
    public ExecutionResult execute(PowerType type, Player boss, Player target) {
        String key = type.configKey();

        if (!plugin.getConfig().getBoolean("abilities." + key + ".enabled", true)) {
            return ExecutionResult.fail("Ese poder esta desactivado en la configuracion.");
        }

        int cooldown = plugin.getConfig().getInt("abilities." + key + ".cooldown", 30);
        long remaining = bossManager.getRemainingCooldownSeconds(key, cooldown);
        if (remaining > 0) {
            String msg = plugin.getConfig().getString("messages.on-cooldown", "&cEn cooldown: %seconds%s")
                    .replace("%seconds%", String.valueOf(remaining));
            return ExecutionResult.fail(stripColorForLog(msg));
        }

        boolean success = switch (type) {
            case METEOR_STORM -> executeMeteorStorm(boss, target);
            case GIANT_SURGE -> executeGiantSurge(boss);
            case SUMMON_ARMY -> executeSummonArmy(boss);
            case POISON_AURA -> executePoisonAura(boss);
            case SEISMIC_SLAM -> executeSeismicSlam(boss);
            case MASS_HEAL -> executeMassHeal(boss);
            case CHARGE_DASH -> executeChargeDash(boss, target);
            case LIGHTNING_RAIN -> executeLightningRain(boss, target);
            case BLIND_FEAR -> executeBlindFear(boss);
            case PHANTOM_DRAGON -> executePhantomDragon(boss);
            case FIRE_NOVA -> executeFireNova(boss);
            case TEMPORARY_SHIELD -> executeTemporaryShield(boss);
        };

        if (success) {
            bossManager.markUsed(key);
            announce(boss, key);
            return ExecutionResult.ok();
        }
        return ExecutionResult.fail("No se pudo ejecutar el poder (revisa que haya un objetivo valido).");
    }

    // ================= PODERES =================

    private boolean executeMeteorStorm(Player boss, Player target) {
        Location center = target != null ? target.getLocation() : boss.getLocation();
        double radius = plugin.getConfig().getDouble("abilities.meteor-storm.radius", 10.0);
        int count = plugin.getConfig().getInt("abilities.meteor-storm.meteor-count", 12);
        double damage = plugin.getConfig().getDouble("abilities.meteor-storm.damage-per-meteor", 6.0);

        for (int i = 0; i < count; i++) {
            long delay = (long) (i * 4L);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                double offsetX = (Math.random() - 0.5) * 2 * radius;
                double offsetZ = (Math.random() - 0.5) * 2 * radius;
                Location fireballSpawn = center.clone().add(offsetX, 15, offsetZ);
                Location impactPoint = center.clone().add(offsetX, 0, offsetZ);

                center.getWorld().spawnParticle(Particle.FLAME, fireballSpawn, 20, 0.3, 0.3, 0.3, 0.02);
                center.getWorld().createExplosion(impactPoint, 2.0f, true, false, boss);

                for (Entity e : center.getWorld().getNearbyEntities(impactPoint, 2.5, 2.5, 2.5)) {
                    if (e instanceof Player p && !p.equals(boss)) {
                        p.damage(damage, boss);
                    }
                }
            }, delay);
        }

        boss.getWorld().playSound(center, Sound.ENTITY_BLAZE_SHOOT, 2.0f, 0.5f);
        return true;
    }

    private boolean executeGiantSurge(Player boss) {
        int durationSeconds = plugin.getConfig().getInt("abilities.giant-surge.duration-seconds", 12);
        double extraScale = plugin.getConfig().getDouble("abilities.giant-surge.extra-scale", 1.5);
        int strengthAmp = plugin.getConfig().getInt("abilities.giant-surge.strength-amplifier", 3);

        bossManager.applyTemporaryScaleBoost(boss, extraScale, durationSeconds * 20);
        boss.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, durationSeconds * 20, strengthAmp, false, true, true));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, durationSeconds * 20, 0, false, false, false));

        boss.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, boss.getLocation(), 5);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 2.0f, 0.6f);
        return true;
    }

    private boolean executeSummonArmy(Player boss) {
        String mobTypeStr = plugin.getConfig().getString("abilities.summon-army.mob-type", "VINDICATOR");
        int amount = plugin.getConfig().getInt("abilities.summon-army.amount", 6);

        EntityType mobType;
        try {
            mobType = EntityType.valueOf(mobTypeStr);
        } catch (IllegalArgumentException e) {
            mobType = EntityType.VINDICATOR;
        }

        Location center = boss.getLocation();
        for (int i = 0; i < amount; i++) {
            double angle = (2 * Math.PI / amount) * i;
            double offsetX = Math.cos(angle) * 3;
            double offsetZ = Math.sin(angle) * 3;
            Location spawnLoc = center.clone().add(offsetX, 0, offsetZ);

            Entity entity = boss.getWorld().spawnEntity(spawnLoc, mobType);
            if (entity instanceof LivingEntity livingEntity) {
                livingEntity.setCustomName("Sirviente de " + boss.getName());
                livingEntity.setCustomNameVisible(true);
            }
        }

        boss.getWorld().spawnParticle(Particle.SMOKE, center, 60, 2, 1, 2, 0.05);
        boss.getWorld().playSound(center, Sound.ENTITY_EVOKER_PREPARE_SUMMON, 1.5f, 0.8f);
        return true;
    }

    private boolean executePoisonAura(Player boss) {
        double radius = plugin.getConfig().getDouble("abilities.poison-aura.radius", 9.0);
        int duration = plugin.getConfig().getInt("abilities.poison-aura.poison-duration-seconds", 8);
        int amplifier = plugin.getConfig().getInt("abilities.poison-aura.poison-amplifier", 2);

        Location center = boss.getLocation();
        for (Entity nearby : boss.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (nearby instanceof Player target && !target.equals(boss)) {
                target.addPotionEffect(new PotionEffect(PotionEffectType.POISON, duration * 20, amplifier));
            }
        }

        boss.getWorld().spawnParticle(Particle.ITEM_SLIME, center, 100, radius / 2, 1, radius / 2, 0.05);
        boss.getWorld().playSound(center, Sound.ENTITY_WITCH_CELEBRATE, 1.5f, 0.7f);
        return true;
    }

    private boolean executeSeismicSlam(Player boss) {
        double radius = plugin.getConfig().getDouble("abilities.seismic-slam.radius", 8.0);
        double damage = plugin.getConfig().getDouble("abilities.seismic-slam.damage", 10.0);
        double knockback = plugin.getConfig().getDouble("abilities.seismic-slam.knockback-strength", 3.0);

        Location center = boss.getLocation();
        for (Entity nearby : boss.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (nearby instanceof Player target && !target.equals(boss)) {
                target.damage(damage, boss);
                Vector direction = target.getLocation().toVector().subtract(center.toVector()).normalize();
                direction.setY(0.6);
                target.setVelocity(direction.multiply(knockback));
            }
        }

        boss.getWorld().spawnParticle(Particle.EXPLOSION, center, 3, 1, 0.2, 1, 0.0);
        boss.getWorld().playSound(center, Sound.ENTITY_RAVAGER_ATTACK, 2.0f, 0.6f);
        return true;
    }

    private boolean executeMassHeal(Player boss) {
        AttributeInstance healthAttr = boss.getAttribute(Attribute.MAX_HEALTH);
        double maxHealth = healthAttr != null ? healthAttr.getBaseValue() : 20.0;
        boss.setHealth(maxHealth);
        bossManager.updateBossBar();

        boss.getWorld().spawnParticle(Particle.HEART, boss.getLocation().add(0, 2, 0), 30, 1, 1, 1, 0.05);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.5f, 1.2f);
        return true;
    }

    private boolean executeChargeDash(Player boss, Player target) {
        Player actualTarget = target;
        double maxRangeSearch = 30.0;

        if (actualTarget == null) {
            double nearestDistance = Double.MAX_VALUE;
            for (Player online : boss.getWorld().getPlayers()) {
                if (online.equals(boss)) continue;
                double distance = online.getLocation().distance(boss.getLocation());
                if (distance <= maxRangeSearch && distance < nearestDistance) {
                    nearestDistance = distance;
                    actualTarget = online;
                }
            }
        }

        if (actualTarget == null) {
            return false;
        }

        double damage = plugin.getConfig().getDouble("abilities.charge-dash.damage", 9.0);
        double dashPower = plugin.getConfig().getDouble("abilities.charge-dash.dash-power", 3.0);

        Vector direction = actualTarget.getLocation().toVector().subtract(boss.getLocation().toVector()).normalize();
        direction.setY(0.3);
        boss.setVelocity(direction.multiply(dashPower));

        Location targetLoc = actualTarget.getLocation();
        for (Entity nearby : boss.getWorld().getNearbyEntities(targetLoc, 3, 3, 3)) {
            if (nearby instanceof Player p && !p.equals(boss)) {
                p.damage(damage, boss);
            }
        }

        boss.getWorld().spawnParticle(Particle.SWEEP_ATTACK, boss.getLocation(), 10, 0.5, 0.5, 0.5, 0.05);
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1.5f, 0.9f);
        return true;
    }

    private boolean executeLightningRain(Player boss, Player target) {
        Location center = target != null ? target.getLocation() : boss.getLocation();
        double radius = plugin.getConfig().getDouble("abilities.lightning-rain.radius", 12.0);
        int strikeCount = plugin.getConfig().getInt("abilities.lightning-rain.strike-count", 8);

        for (int i = 0; i < strikeCount; i++) {
            long delay = (long) (i * 5L);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                double offsetX = (Math.random() - 0.5) * 2 * radius;
                double offsetZ = (Math.random() - 0.5) * 2 * radius;
                Location strikeLoc = center.clone().add(offsetX, 0, offsetZ);
                center.getWorld().strikeLightning(strikeLoc);
            }, delay);
        }

        return true;
    }

    private boolean executeBlindFear(Player boss) {
        double radius = plugin.getConfig().getDouble("abilities.blind-fear.radius", 15.0);
        int duration = plugin.getConfig().getInt("abilities.blind-fear.duration-seconds", 6);

        Location center = boss.getLocation();
        for (Entity nearby : boss.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (nearby instanceof Player target && !target.equals(boss)) {
                target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, duration * 20, 0));
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, duration * 20, 2));
            }
        }

        boss.getWorld().spawnParticle(Particle.SOUL, center, 80, radius / 2, 1, radius / 2, 0.05);
        boss.getWorld().playSound(center, Sound.ENTITY_WARDEN_ROAR, 2.0f, 0.5f);
        return true;
    }

    private boolean executePhantomDragon(Player boss) {
        int durationSeconds = plugin.getConfig().getInt("abilities.phantom-dragon.duration-seconds", 20);
        Location spawnLoc = boss.getLocation().add(0, 10, 0);

        Entity entity = boss.getWorld().spawnEntity(spawnLoc, EntityType.ENDER_DRAGON);
        if (entity instanceof EnderDragon dragon) {
            dragon.setCustomName("Fantasma de " + boss.getName());
            dragon.setCustomNameVisible(true);
            dragon.setGlowing(true);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!dragon.isDead()) {
                    dragon.getWorld().spawnParticle(Particle.CLOUD, dragon.getLocation(), 60, 1, 1, 1, 0.1);
                    dragon.remove();
                }
            }, durationSeconds * 20L);
        }

        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_ENDER_DRAGON_AMBIENT, 2.0f, 1.0f);
        return true;
    }

    private boolean executeFireNova(Player boss) {
        double radius = plugin.getConfig().getDouble("abilities.fire-nova.radius", 8.0);
        int fireDuration = plugin.getConfig().getInt("abilities.fire-nova.fire-duration-seconds", 5);

        Location center = boss.getLocation();
        for (Entity nearby : boss.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (nearby instanceof Player target && !target.equals(boss)) {
                target.setFireTicks(fireDuration * 20);
            }
        }

        boss.getWorld().spawnParticle(Particle.FLAME, center, 100, radius / 2, 0.5, radius / 2, 0.05);
        boss.getWorld().playSound(center, Sound.ENTITY_BLAZE_SHOOT, 2.0f, 0.6f);
        return true;
    }

    private boolean executeTemporaryShield(Player boss) {
        int durationSeconds = plugin.getConfig().getInt("abilities.temporary-shield.duration-seconds", 8);

        boss.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, durationSeconds * 20, 4, false, true, true));
        boss.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, durationSeconds * 20, 0, false, false, false));

        boss.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, boss.getLocation(), 80, 1, 1, 1, 0.1);
        boss.getWorld().playSound(boss.getLocation(), Sound.ITEM_TOTEM_USE, 1.5f, 1.0f);
        return true;
    }

    // ================= UTILIDADES =================

    private void announce(Player boss, String configKey) {
        String displayName = plugin.getConfig().getString("abilities." + configKey + ".display-name", configKey);
        String rawMsg = plugin.getConfig().getString("messages.ability-used", "%player% uso: %ability%")
                .replace("%player%", boss.getName())
                .replace("%ability%", stripColorForLog(displayName));
        bossManager.broadcast(rawMsg);
    }

    private String stripColorForLog(String text) {
        return text.replaceAll("&[0-9a-fk-or]", "");
    }
}
