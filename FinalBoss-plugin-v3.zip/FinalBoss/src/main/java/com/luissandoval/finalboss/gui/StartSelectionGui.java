package com.luissandoval.finalboss.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * GUI que se abre al ejecutar /finalboss start: permite elegir quien sera
 * el Final Boss (quien ejecuta el comando mismo, o cualquier otro jugador online).
 */
public class StartSelectionGui {

    public static final String TITLE_RAW = "&4&l☠ ¿Quien sera el Final Boss? ☠";

    public static Inventory build(Player requester, Map<Integer, UUID> outSlotMap) {
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(TITLE_RAW);
        Inventory inv = Bukkit.createInventory(null, 27, title);

        ItemStack filler = createFiller();
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        // Opcion: yo mismo
        ItemStack selfItem = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta selfMeta = (SkullMeta) selfItem.getItemMeta();
        selfMeta.setOwningPlayer(requester);
        Component selfName = LegacyComponentSerializer.legacyAmpersand()
                .deserialize("&d&l✦ Yo mismo (" + requester.getName() + ")")
                .decoration(TextDecoration.ITALIC, false);
        selfMeta.displayName(selfName);
        List<Component> selfLore = new ArrayList<>();
        selfLore.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&7Te conviertes tu en el Final Boss")
                .decoration(TextDecoration.ITALIC, false));
        selfMeta.lore(selfLore);
        selfItem.setItemMeta(selfMeta);
        inv.setItem(4, selfItem);
        outSlotMap.put(4, requester.getUniqueId());

        // Opciones: cada jugador online excepto quien ejecuta el comando
        int slot = 10;
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.equals(requester)) continue;
            if (slot > 25) break;

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(online);
            Component name = LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&c☠ " + online.getName())
                    .decoration(TextDecoration.ITALIC, false);
            meta.displayName(name);
            List<Component> lore = new ArrayList<>();
            lore.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&7Click para convertir a este jugador en el Final Boss")
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);
            head.setItemMeta(meta);

            inv.setItem(slot, head);
            outSlotMap.put(slot, online.getUniqueId());
            slot++;
        }

        return inv;
    }

    private static ItemStack createFiller() {
        ItemStack filler = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.displayName(Component.text(" "));
        filler.setItemMeta(meta);
        return filler;
    }
}
