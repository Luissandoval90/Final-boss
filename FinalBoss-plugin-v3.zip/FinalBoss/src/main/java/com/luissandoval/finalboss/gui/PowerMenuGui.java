package com.luissandoval.finalboss.gui;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.manager.BossManager;
import com.luissandoval.finalboss.model.PowerType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Construye el GUI principal de seleccion de poderes (36 slots, hasta 12 poderes en fila).
 */
public class PowerMenuGui {

    public static final String TITLE_RAW = "&4&l☠ Menu de Poderes - Final Boss ☠";

    // Mapeo fijo slot -> poder, en orden de definicion del enum
    private static final Map<Integer, PowerType> SLOT_MAP = buildSlotMap();

    private static Map<Integer, PowerType> buildSlotMap() {
        Map<Integer, PowerType> map = new LinkedHashMap<>();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23};
        PowerType[] powers = PowerType.values();
        for (int i = 0; i < powers.length && i < slots.length; i++) {
            map.put(slots[i], powers[i]);
        }
        return map;
    }

    public static Map<Integer, PowerType> getSlotMap() {
        return SLOT_MAP;
    }

    public static Inventory build(FinalBossPlugin plugin, BossManager bossManager) {
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(TITLE_RAW);
        Inventory inv = org.bukkit.Bukkit.createInventory(null, 36, title);

        ItemStack filler = createFiller();
        for (int i = 0; i < 36; i++) {
            inv.setItem(i, filler);
        }

        for (Map.Entry<Integer, PowerType> entry : SLOT_MAP.entrySet()) {
            int slot = entry.getKey();
            PowerType type = entry.getValue();
            inv.setItem(slot, createPowerIcon(plugin, bossManager, type));
        }

        return inv;
    }

    private static ItemStack createFiller() {
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.displayName(Component.text(" "));
        filler.setItemMeta(meta);
        return filler;
    }

    public static ItemStack createPowerIcon(FinalBossPlugin plugin, BossManager bossManager, PowerType type) {
        String key = type.configKey();
        String displayName = plugin.getConfig().getString("abilities." + key + ".display-name", key);
        String lore = plugin.getConfig().getString("abilities." + key + ".lore", "");
        int cooldownSeconds = plugin.getConfig().getInt("abilities." + key + ".cooldown", 30);
        boolean enabled = plugin.getConfig().getBoolean("abilities." + key + ".enabled", true);

        Material material = iconMaterialFor(type);
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        Component nameComponent = LegacyComponentSerializer.legacyAmpersand().deserialize(displayName)
                .decoration(TextDecoration.ITALIC, false);
        meta.displayName(nameComponent);

        long remaining = bossManager.getRemainingCooldownSeconds(key, cooldownSeconds);

        List<Component> loreLines = new ArrayList<>();
        loreLines.add(LegacyComponentSerializer.legacyAmpersand().deserialize(lore)
                .decoration(TextDecoration.ITALIC, false));
        loreLines.add(Component.empty());

        if (!enabled) {
            loreLines.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&cDesactivado en config")
                    .decoration(TextDecoration.ITALIC, false));
        } else if (remaining > 0) {
            loreLines.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&c⏱ Cooldown: &e" + remaining + "s")
                    .decoration(TextDecoration.ITALIC, false));
        } else {
            loreLines.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&a✔ Listo para usar")
                    .decoration(TextDecoration.ITALIC, false));
        }

        meta.lore(loreLines);
        item.setItemMeta(meta);
        return item;
    }

    private static Material iconMaterialFor(PowerType type) {
        return switch (type) {
            case METEOR_STORM -> Material.FIRE_CHARGE;
            case GIANT_SURGE -> Material.IRON_BLOCK;
            case SUMMON_ARMY -> Material.IRON_SWORD;
            case POISON_AURA -> Material.SPIDER_EYE;
            case SEISMIC_SLAM -> Material.NETHERITE_PICKAXE;
            case MASS_HEAL -> Material.GOLDEN_APPLE;
            case CHARGE_DASH -> Material.FEATHER;
            case LIGHTNING_RAIN -> Material.TRIDENT;
            case BLIND_FEAR -> Material.WITHER_SKELETON_SKULL;
            case PHANTOM_DRAGON -> Material.DRAGON_EGG;
            case FIRE_NOVA -> Material.BLAZE_POWDER;
            case TEMPORARY_SHIELD -> Material.SHIELD;
        };
    }
}
