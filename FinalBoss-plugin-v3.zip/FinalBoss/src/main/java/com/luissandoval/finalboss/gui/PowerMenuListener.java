package com.luissandoval.finalboss.gui;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.ability.PowerExecutor;
import com.luissandoval.finalboss.manager.BossManager;
import com.luissandoval.finalboss.model.PowerType;
import com.luissandoval.finalboss.model.TargetMode;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Escucha clics en el GUI principal de poderes y en el GUI de seleccion de objetivo,
 * encadenando ambos: poder SELF_OR_OTHER -> abre seleccion -> ejecuta con el objetivo elegido.
 */
public class PowerMenuListener implements Listener {

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;

    // Estado temporal: que poder esta pendiente de seleccion de objetivo para cada boss (deberia ser solo 1 jugador, pero es robusto)
    private final Map<UUID, PowerType> pendingPowerSelection = new HashMap<>();
    // Estado temporal: mapa slot->UUID objetivo del GUI de seleccion actualmente abierto por jugador
    private final Map<UUID, Map<Integer, UUID>> openTargetGuiSlotMaps = new HashMap<>();

    public PowerMenuListener(FinalBossPlugin plugin, BossManager bossManager) {
        this.plugin = plugin;
        this.bossManager = bossManager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = LegacyComponentSerializer.legacyAmpersand().serialize(event.getView().title());
        String plainTitleMenu = stripColor(PowerMenuGui.TITLE_RAW);
        String plainTitleTarget = stripColor(TargetSelectionGui.TITLE_RAW);
        String currentPlainTitle = stripColor(title);

        boolean isPowerMenu = currentPlainTitle.equals(plainTitleMenu);
        boolean isTargetMenu = currentPlainTitle.equals(plainTitleTarget);

        if (!isPowerMenu && !isTargetMenu) return;

        event.setCancelled(true);

        int slot = event.getRawSlot();
        Inventory clickedInv = event.getClickedInventory();
        if (clickedInv == null || !clickedInv.equals(event.getView().getTopInventory())) {
            return; // clic en inventario del jugador, ignorar
        }

        if (isPowerMenu) {
            handlePowerMenuClick(player, slot);
        } else {
            handleTargetMenuClick(player, slot);
        }
    }

    private void handlePowerMenuClick(Player player, int slot) {
        PowerType type = PowerMenuGui.getSlotMap().get(slot);
        if (type == null) return;

        if (!bossManager.isBoss(player)) {
            player.sendMessage(prefixed("&cSolo el Final Boss puede usar este menu."));
            return;
        }

        TargetMode mode = targetModeFor(type);

        if (mode == TargetMode.SELF_OR_OTHER) {
            pendingPowerSelection.put(player.getUniqueId(), type);
            Map<Integer, UUID> slotMap = new HashMap<>();
            Inventory targetGui = TargetSelectionGui.build(player, type, slotMap);
            openTargetGuiSlotMaps.put(player.getUniqueId(), slotMap);
            player.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> player.openInventory(targetGui));
        } else {
            executePower(player, type, null);
        }
    }

    private void handleTargetMenuClick(Player player, int slot) {
        PowerType pendingType = pendingPowerSelection.get(player.getUniqueId());
        Map<Integer, UUID> slotMap = openTargetGuiSlotMaps.get(player.getUniqueId());

        if (pendingType == null || slotMap == null || !slotMap.containsKey(slot)) {
            return;
        }

        UUID targetUuid = slotMap.get(slot);
        Player target = targetUuid != null ? Bukkit.getPlayer(targetUuid) : player;

        player.closeInventory();
        pendingPowerSelection.remove(player.getUniqueId());
        openTargetGuiSlotMaps.remove(player.getUniqueId());

        executePower(player, pendingType, target);
    }

    private void executePower(Player boss, PowerType type, Player target) {
        PowerExecutor.ExecutionResult result = bossManager.getPowerExecutor().execute(type, boss, target);
        if (!result.isSuccess()) {
            boss.sendMessage(prefixed("&c" + result.getFailureMessage()));
        }
    }

    private TargetMode targetModeFor(PowerType type) {
        String raw = plugin.getConfig().getString("abilities." + type.configKey() + ".target-mode", "NONE");
        try {
            return TargetMode.valueOf(raw);
        } catch (IllegalArgumentException e) {
            return TargetMode.NONE;
        }
    }

    private String stripColor(String text) {
        return text.replaceAll("&[0-9a-fk-or]", "");
    }

    private net.kyori.adventure.text.Component prefixed(String rawMsg) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        return LegacyComponentSerializer.legacyAmpersand().deserialize(prefix + rawMsg);
    }
}
