package com.luissandoval.finalboss.model;

/**
 * Todos los poderes disponibles para el Final Boss.
 * El "configKey" debe coincidir exactamente con la clave en config.yml bajo "abilities".
 */
public enum PowerType {
    METEOR_STORM("meteor-storm"),
    GIANT_SURGE("giant-surge"),
    SUMMON_ARMY("summon-army"),
    POISON_AURA("poison-aura"),
    SEISMIC_SLAM("seismic-slam"),
    MASS_HEAL("mass-heal"),
    CHARGE_DASH("charge-dash"),
    LIGHTNING_RAIN("lightning-rain"),
    BLIND_FEAR("blind-fear"),
    PHANTOM_DRAGON("phantom-dragon"),
    FIRE_NOVA("fire-nova"),
    TEMPORARY_SHIELD("temporary-shield");

    private final String configKey;

    PowerType(String configKey) {
        this.configKey = configKey;
    }

    public String configKey() {
        return configKey;
    }

    public static PowerType fromConfigKey(String key) {
        for (PowerType type : values()) {
            if (type.configKey.equals(key)) {
                return type;
            }
        }
        return null;
    }
}
