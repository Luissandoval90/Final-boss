package com.luissandoval.finalboss.manager;

import com.luissandoval.finalboss.FinalBossPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Reproduce la secuencia de aparicion "estilo Warden" cuando el Final Boss se activa:
 * oscuridad subita, rugido grave, particulas de sonic-boom/emergencia, y musica epica de fondo.
 */
public class SpawnEffectManager {

    private final FinalBossPlugin plugin;

    public SpawnEffectManager(FinalBossPlugin plugin) {
        this.plugin = plugin;
    }

    public void playSpawnSequence(Player boss) {
        if (!plugin.getConfig().getBoolean("spawn-effects.enabled", true)) {
            return;
        }

        double darknessRadius = plugin.getConfig().getDouble("spawn-effects.darkness-radius", 40.0);
        int darknessDuration = plugin.getConfig().getInt("spawn-effects.darkness-duration-seconds", 4);
        String rumbleSoundName = plugin.getConfig().getString("spawn-effects.rumble-sound", "ENTITY_WARDEN_ROAR");
        String musicSoundName = plugin.getConfig().getString("spawn-effects.music-sound", "MUSIC_DISC_OTHERSIDE");
        double musicVolume = plugin.getConfig().getDouble("spawn-effects.music-volume", 3.0);
        int emergeDuration = plugin.getConfig().getInt("spawn-effects.emerge-duration-seconds", 3);

        Location center = boss.getLocation();

        Sound rumbleSound = safeSound(rumbleSoundName, Sound.ENTITY_WARDEN_ROAR);
        Sound musicSound = safeSound(musicSoundName, Sound.MUSIC_DISC_OTHERSIDE);

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, darknessDuration * 20, 0, false, false, false));
            p.playSound(p.getLocation(), rumbleSound, 3.0f, 0.6f);
        }

        center.getWorld().spawnParticle(Particle.SONIC_BOOM, center, 1);
        center.getWorld().spawnParticle(Particle.SCULK_SOUL, center, 40, 1.5, 1, 1.5, 0.05);
        center.getWorld().spawnParticle(Particle.WARPED_SPORE, center, 60, 2, 2, 2, 0.05);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.playSound(p.getLocation(), musicSound, (float) musicVolume, 1.0f);
            }
        }, 20L);

        int totalTicks = emergeDuration * 20;
        int stepTicks = 4;
        for (int t = 0; t <= totalTicks; t += stepTicks) {
            long delay = t;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                center.getWorld().spawnParticle(Particle.SCULK_SOUL, center, 8, 0.6, 0.2, 0.6, 0.02);
                center.getWorld().spawnParticle(Particle.ASH, center, 15, 1, 0.3, 1, 0.02);
            }, delay);
        }
    }

    private Sound safeSound(String name, Sound fallback) {
        try {
            return Sound.valueOf(name);
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
