package com.luissandoval.finalboss.gui;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.manager.CountdownManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Escucha clics en el GUI de "quien sera el Final Boss" (abierto por /finalboss start)
 * y, al elegir un jugador, dispara la cuenta regresiva antes de activarlo.
 */
public class StartSelectionListener implements Listener {

    private final FinalBossPlugin plugin;
    private final CountdownManager countdownManager;

    // slot->UUID del GUI de inicio actualmente abierto por cada solicitante
    private final Map<UUID, Map<Integer, UUID>> openStartGuiSlotMaps = new HashMap<>();

    public StartSelectionListener(FinalBossPlugin plugin, CountdownManager countdownManager) {
        this.plugin = plugin;
        this.countdownManager = countdownManager;
    }

    public void registerOpenGui(Player requester, Map<Integer, UUID> slotMap) {
        openStartGuiSlotMaps.put(requester.getUniqueId(), slotMap);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String currentPlainTitle = stripColor(LegacyComponentSerializer.legacyAmpersand().serialize(event.getView().title()));
        String plainTitleStart = stripColor(StartSelectionGui.TITLE_RAW);

        if (!currentPlainTitle.equals(plainTitleStart)) return;

        event.setCancelled(true);

        Inventory clickedInv = event.getClickedInventory();
        if (clickedInv == null || !clickedInv.equals(event.getView().getTopInventory())) {
            return;
        }

        Map<Integer, UUID> slotMap = openStartGuiSlotMaps.get(player.getUniqueId());
        if (slotMap == null) return;

        int slot = event.getRawSlot();
        if (!slotMap.containsKey(slot)) return;

        UUID chosenUuid = slotMap.get(slot);
        Player chosenBoss = Bukkit.getPlayer(chosenUuid);

        player.closeInventory();
        openStartGuiSlotMaps.remove(player.getUniqueId());

        if (chosenBoss == null || !chosenBoss.isOnline()) {
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&cEse jugador ya no esta en linea."));
            return;
        }

        countdownManager.startCountdown(chosenBoss);
    }

    private String stripColor(String text) {
        return text.replaceAll("&[0-9a-fk-or]", "");
    }
}
