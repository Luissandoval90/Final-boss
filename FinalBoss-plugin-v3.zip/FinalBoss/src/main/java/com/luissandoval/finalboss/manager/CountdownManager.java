package com.luissandoval.finalboss.manager;

import com.luissandoval.finalboss.FinalBossPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;

/**
 * Muestra una cuenta regresiva visible para todo el servidor (Title grande + sonido de tick)
 * antes de activar formalmente al Final Boss. Nada del boss (escala, item, bossbar) aparece
 * hasta que el contador llega a 0.
 */
public class CountdownManager {

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;

    private boolean countdownInProgress = false;
    private BukkitTask countdownTask;

    public CountdownManager(FinalBossPlugin plugin, BossManager bossManager) {
        this.plugin = plugin;
        this.bossManager = bossManager;
    }

    public boolean isCountdownInProgress() {
        return countdownInProgress;
    }

    /**
     * Inicia la cuenta regresiva configurada (por defecto 10s). Al finalizar, activa al boss.
     */
    public void startCountdown(Player futureBoss) {
        if (countdownInProgress || bossManager.isActive()) {
            return;
        }

        countdownInProgress = true;
        int totalSeconds = plugin.getConfig().getInt("activation.countdown-seconds", 10);

        String rawAnnounce = plugin.getConfig().getString("messages.countdown-announce",
                        "&c&l¡%player% se convertira en el FINAL BOSS en %seconds% segundos!")
                .replace("%player%", futureBoss.getName())
                .replace("%seconds%", String.valueOf(totalSeconds));
        bossManager.broadcast(rawAnnounce);

        int[] remaining = {totalSeconds};

        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (remaining[0] <= 0) {
                if (countdownTask != null) {
                    countdownTask.cancel();
                    countdownTask = null;
                }
                countdownInProgress = false;
                bossManager.activate(futureBoss);
                return;
            }

            broadcastCountdownTick(futureBoss, remaining[0]);
            remaining[0]--;
        }, 0L, 20L);
    }

    private void broadcastCountdownTick(Player futureBoss, int secondsLeft) {
        Component title = LegacyComponentSerializer.legacyAmpersand()
                .deserialize("&c&l" + secondsLeft);
        Component subtitle = LegacyComponentSerializer.legacyAmpersand()
                .deserialize("&7" + futureBoss.getName() + " &7se convertira en el &4&lFINAL BOSS");

        Title displayTitle = Title.title(
                title,
                subtitle,
                Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(900), Duration.ofMillis(200))
        );

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(displayTitle);
            float pitch = secondsLeft <= 3 ? 2.0f : 1.0f;
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, pitch);
        }
    }

    public void cancelCountdown() {
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }
        countdownInProgress = false;
    }
}
