package com.luissandoval.finalboss.listener;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.manager.BossManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Este listener existe para dejar explicito (y auditable) que el Final Boss
 * SIEMPRE puede recibir daño normal de otros jugadores. No cancela ni reduce
 * el daño recibido por el boss mas alla de sus atributos normales (resistencia %),
 * que ya se aplican via AttributeModifier y no mediante cancelacion de eventos.
 */
public class CombatListener implements Listener {

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;

    public CombatListener(FinalBossPlugin plugin, BossManager bossManager) {
        this.plugin = plugin;
        this.bossManager = bossManager;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!bossManager.isActive() || !bossManager.isBoss(victim)) return;

        // Intencionalmente no se cancela el evento: el boss debe poder ser golpeado
        // por jugadores normalmente. La resistencia porcentual ya viene de ARMOR_TOUGHNESS.
    }
}
