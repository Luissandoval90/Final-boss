package com.luissandoval.finalboss.listener;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.manager.BossManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.GameMode;

public class PlayerDeathListener implements Listener {

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;

    public PlayerDeathListener(FinalBossPlugin plugin, BossManager bossManager) {
        this.plugin = plugin;
        this.bossManager = bossManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();

        if (bossManager.isActive() && dead.getUniqueId().equals(bossManager.getBossUuid())) {
            Player killer = dead.getKiller();
            bossManager.deactivate(true, killer);
            return;
        }

        checkAutoActivation();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (bossManager.isActive() && event.getPlayer().getUniqueId().equals(bossManager.getBossUuid())) {
            bossManager.deactivate(true);
            return;
        }
        checkAutoActivation();
    }

    private void checkAutoActivation() {
        if (bossManager.isActive()) return;
        if (!plugin.getConfig().getBoolean("activation.auto-activate", true)) return;

        int trigger = plugin.getConfig().getInt("activation.players-remaining-trigger", 5);
        String bossName = plugin.getConfig().getString("boss-player", "");

        if (bossName == null || bossName.isBlank()) return;

        Player bossPlayer = Bukkit.getPlayerExact(bossName);
        if (bossPlayer == null || !bossPlayer.isOnline()) return;

        long aliveNonBossPlayers = Bukkit.getOnlinePlayers().stream()
                .filter(p -> !p.getUniqueId().equals(bossPlayer.getUniqueId()))
                .filter(p -> p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE)
                .count();

        if (aliveNonBossPlayers <= trigger) {
            bossManager.activate(bossPlayer);
        }
    }
}
