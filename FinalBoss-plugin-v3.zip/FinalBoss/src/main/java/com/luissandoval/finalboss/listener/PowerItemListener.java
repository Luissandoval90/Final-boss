package com.luissandoval.finalboss.listener;

import com.luissandoval.finalboss.FinalBossPlugin;
import com.luissandoval.finalboss.gui.PowerMenuGui;
import com.luissandoval.finalboss.manager.BossManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Detecta el uso (clic derecho) del item fisico "Menu de Poderes" y abre el GUI principal.
 * Tambien evita que el boss lo tire, lo mueva a otro slot o lo pierda accidentalmente.
 */
public class PowerItemListener implements Listener {

    private final FinalBossPlugin plugin;
    private final BossManager bossManager;

    public PowerItemListener(FinalBossPlugin plugin, BossManager bossManager) {
        this.plugin = plugin;
        this.bossManager = bossManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || !plugin.getPowerItemManager().isPowerItem(item)) return;

        event.setCancelled(true);

        if (!bossManager.isActive() || !bossManager.isBoss(event.getPlayer())) {
            return;
        }

        event.getPlayer().openInventory(PowerMenuGui.build(plugin, bossManager));
    }

    @EventHandler
    public void onDropItem(PlayerDropItemEvent event) {
        ItemStack item = event.getItemDrop().getItemStack();
        if (plugin.getPowerItemManager().isPowerItem(item)) {
            event.setCancelled(true);
        }
    }
}
