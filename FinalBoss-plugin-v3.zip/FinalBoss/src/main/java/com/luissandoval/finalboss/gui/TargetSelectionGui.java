package com.luissandoval.finalboss.gui;

import com.luissandoval.finalboss.model.PowerType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * GUI de seleccion de objetivo: aparece cuando un poder es SELF_OR_OTHER.
 * Muestra "A mi mismo" en el slot 4, y una cabeza por cada jugador online (excepto el boss) debajo.
 */
public class TargetSelectionGui {

    public static final String TITLE_RAW = "&5&l¿A quien afecta el poder?";

    // slot -> UUID del jugador objetivo (null = el propio boss)
    public static Inventory build(Player boss, PowerType pendingPower, Map<Integer, UUID> outSlotMap) {
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(TITLE_RAW);
        Inventory inv = Bukkit.createInventory(null, 27, title);

        ItemStack filler = createFiller();
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        // Opcion: a mi mismo
        ItemStack selfItem = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta selfMeta = (SkullMeta) selfItem.getItemMeta();
        selfMeta.setOwningPlayer(boss);
        Component selfName = LegacyComponentSerializer.legacyAmpersand()
                .deserialize("&d&l✦ A mi mismo (" + boss.getName() + ")")
                .decoration(TextDecoration.ITALIC, false);
        selfMeta.displayName(selfName);
        List<Component> selfLore = new ArrayList<>();
        selfLore.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&7Aplicas el poder sobre ti mismo")
                .decoration(TextDecoration.ITALIC, false));
        selfMeta.lore(selfLore);
        selfItem.setItemMeta(selfMeta);
        inv.setItem(4, selfItem);
        outSlotMap.put(4, null);

        // Opciones: cada jugador online excepto el boss
        int slot = 10;
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.equals(boss)) continue;
            if (slot > 25) break; // limite de slots disponibles en esta fila/zona

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(online);
            Component name = LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&c⚔ " + online.getName())
                    .decoration(TextDecoration.ITALIC, false);
            meta.displayName(name);
            List<Component> lore = new ArrayList<>();
            lore.add(LegacyComponentSerializer.legacyAmpersand().deserialize("&7Click para usar el poder en este jugador")
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);
            head.setItemMeta(meta);

            inv.setItem(slot, head);
            outSlotMap.put(slot, online.getUniqueId());
            slot++;
        }

        return inv;
    }

    private static ItemStack createFiller() {
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.displayName(Component.text(" "));
        filler.setItemMeta(meta);
        return filler;
    }
}
