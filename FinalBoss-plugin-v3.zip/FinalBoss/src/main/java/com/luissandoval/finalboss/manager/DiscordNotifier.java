package com.luissandoval.finalboss.manager;

import com.luissandoval.finalboss.FinalBossPlugin;
import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/**
 * Envia notificaciones simples a un Discord Webhook.
 * Si "discord.webhook-url" esta vacio, no hace nada (silenciosamente desactivado).
 */
public class DiscordNotifier {

    private final FinalBossPlugin plugin;

    public DiscordNotifier(FinalBossPlugin plugin) {
        this.plugin = plugin;
    }

    public void sendMessage(String content) {
        String webhookUrl = plugin.getConfig().getString("discord.webhook-url", "");
        if (webhookUrl == null || webhookUrl.isBlank()) {
            return;
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                URI uri = URI.create(webhookUrl);
                HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                connection.setDoOutput(true);

                String jsonPayload = "{\"content\": \"" + escapeJson(content) + "\"}";

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                int responseCode = connection.getResponseCode();
                if (responseCode >= 400) {
                    plugin.getLogger().warning("Discord webhook respondio con codigo: " + responseCode);
                }
                connection.disconnect();
            } catch (Exception e) {
                plugin.getLogger().warning("Error enviando notificacion a Discord: " + e.getMessage());
            }
        });
    }

    private String escapeJson(String text) {
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n");
    }
}
