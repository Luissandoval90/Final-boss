package com.luissandoval.finalboss.model;

/**
 * Define si una habilidad necesita seleccion de objetivo via GUI.
 */
public enum TargetMode {
    NONE,           // No requiere objetivo, se aplica al boss o en area alrededor del boss
    SELF_OR_OTHER   // El boss elige en un GUI si se la aplica a si mismo o a otro jugador
}
